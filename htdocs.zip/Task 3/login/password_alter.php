<!-- Password alert 
Written by ZHAO -->
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
	<title>Alter Password</title>
	<style type="text/css">
		ul li{margin:0;padding:0;}
		form{margin:40px 30px 0;}
		form li{list-style:none;padding:5px 0;}
		form li label{float:left;width:130px;text-align:right}
		form li a{font-size:12px;color:#999;text-decoration:none}
		.login_btn{border:none;background:#666;color:#fff;font-size:14px;font-weight:bold;height:28px;line-height:28px;padding:0 10px;cursor:pointer;}
		form li img{vertical-align:top}
	</style>
 
</head>
<body background="../img/woll.png"
style=" background-repeat:repeat"
>
<form action="password_alter.php" method="POST">
	<fieldset>
		<legend>Alter Password</legend>
		<ul>
			<li>
				<label for"">Username:</label>
				<input type="text" name="username"/>
			</li>
			<li>
				<label for"">Old Password:</label>
				<input type="password" name="old_password"/>
            </li>
            <li>
				<label for"">New Password:</label>
				<input type="password" name="new_password"/>
            </li>
            <li>
				<label for"">Confirm Password:</label>
				<input type="password" name="new_password_conf"/>
			</li>
            <li>
				<label for""> </label>
                <input type="submit" name="alter_comfirm" value="confirm" onclick="alert()" class="login_btn"/>
                <script>
                    function alert(){
                        return confirm("Are you sure to alter the password?");
                    }
                </script>
            </li>
            </li>
		</ul>
    </fieldset>
    <p class="title" align="left"><font class="char">&emsp;&emsp;&emsp;&emsp;&emsp;<a href="../index.html">Back</a></font></p>
</body>
 
</html>

<?php

header("Content-type:text/html;charset=utf-8");
header("Access-Control-Allow-Origin: *");

session_start();

if (isset($_POST["alter_comfirm"])) {//The user confirm to alter password
    include "../database/connect_sql.php";

    $username = $_POST['username'];
    $old_password = $_POST['old_password'];

    $sql = "SELECT  user_name,password FROM user WHERE  user_name = '$username' AND password = '$old_password';";
    $result = mysqli_query($link, $sql);
    if (!$result) {
        printf("Error: %s\n", mysqli_error($link));
        exit();
    }
    $row = mysqli_num_rows($result);

    if ($row == 1) {//the username and password match
        $new_password = $_POST['new_password'];
        $new_password_conf = $_POST['new_password_conf'];

        if ($new_password == $new_password_conf) {//check the two enteries of new password are the same
            $sql = "UPDATE user SET password = '$new_password' WHERE user_name = '$username';";
            $result = mysqli_query($link, $sql);
            if (!$result) {
                printf("Error: %s\n", mysqli_error($link));
                exit();
            }else{  //alter successfully
                echo "Alter successfully!You can go back to main page.";
            }
        }else{//two enteries of new password are not same
            echo "The new password are not same!";
        }
    }
    else {  //old password is wrong
        echo "old password is wrong or the username is wrong!";
    }

}

