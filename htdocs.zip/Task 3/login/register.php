<!-- Register page 
Writen by ZHAO -->
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
	<title>Register</title>
	<style type="text/css">
		ul li{margin:0;padding:0;}
		form{margin:40px 30px 0;}
		form li{list-style:none;padding:5px 0;}
		form li label{float:left;width:130px;text-align:right}
		form li a{font-size:12px;color:#999;text-decoration:none}
		.login_btn{border:none;background:#666;color:#fff;font-size:14px;font-weight:bold;height:28px;line-height:28px;padding:0 10px;cursor:pointer;}
		form li img{vertical-align:top}
	</style>
 
</head>
<body background="../img/woll.png"
style=" background-repeat:repeat"
>
<form action="register.php" method="POST">
	<fieldset>
		<legend>User Register</legend>
		<ul>
			<li>
				<label for"">Useername:</label>
				<input type="text" name="username"/>
			</li>
			<li>
				<label for"">Password:</label>
				<input type="password" name="password"/>
            </li>
            <li>
				<label for"">Confirm Password:</label>
				<input type="password" name="confirm"/>
			</li>
            <li>
				<label for""> </label>
				<input type="submit" name="register_comfirm" value="Confirm" class="login_btn" οnclick="javascrtpt:window.location.href='register.php'"/>
            </li>
            </li>
		</ul>
    </fieldset>
    <p class="title" align="left"><font class="char">&emsp;&emsp;&emsp;&emsp;&emsp;<a href="../index.html">Go back</a></font></p>
</body>
 
</html>
<?php


session_start();

if(isset($_POST["register_comfirm"]) ) {
    $username = $_POST["username"];
    $password = $_POST["password"];
    $password_conf = $_POST["confirm"];

    if($username == "" || $password == "" || $password == "" || $password_conf == "") {  //user infotmation is not completed
        echo "please fill all informatiom!";
    }
    else {
        if($password == $password_conf) {
            include "../database/connect_sql.php";

            $sql = "select user_name from user where user_name = '$_POST[username]'"; 
            $result = mysqli_query($link, $sql);    
            if (!$result) {
                printf("Error: %s\n", mysqli_error($link));
                exit();
            }
            $num = mysqli_num_rows($result);
            if($num) {   //if the username is already existed
                echo "The username is already occurred!";
            }
            else {   //The username is not occurred
                $sql_insert = "insert into user (user_name, password)
                      values('$_POST[username]', '$_POST[password]')";
                $res_insert = mysqli_query($link, $sql_insert);
                if($res_insert) {   //successfully
                    // $sql_insert = "insert into bank (word, user_name)
                    //   values('Fisch', '$_POST[username]')";
                    // $res_insert = mysqli_query($link, $sql_insert);
                    echo "Register successfully!";
                }
                else {
                    echo "something wrong, try again later";
                }
            }
        }
        else {  //Two times entries are not the same
            echo "The password is not the same!";
        }
    }

}
?>
