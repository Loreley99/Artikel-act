<!-- user mainpage
written by ZHAO -->
<html>

<head>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
	<title>User Center</title>
	<style type="text/css">
		ul li{margin:0;padding:0;}
		form{margin:40px 30px 0;}
		form li{list-style:none;padding:5px 0;}
		form li a{font-size:12px;color:#999;text-decoration:none}
		.login_btn{border:none;background:#666;color:#fff;font-size:14px;font-weight:bold;height:28px;padding:0 10px;line-height:28px;cursor:pointer;}
		form li img{vertical-align:top}
	</style>
</head>

<body background="../img/bone.png"
style=" background-repeat:repeat;"

>

	<fieldset>
		<legend>Study New Word,Choose the category you want to learn</legend>

		<!-- Module that can select different categories to learn -->
		<ul>
			<form action="../quiz/wordquiz1.html" method="POST">
			<li>
				<input type="submit" value="Lebensmittel" class="login_btn"/>
			</li>
			</form>
			<form action="../quiz/wordquiz2.html" method="POST">
				<li>
					<input type="submit" value="Koerper" class="login_btn"/>
				</li>
			</form>
			<form action="../quiz/wordquiz3.html" method="POST">
				<li>
					<input type="submit" value="Vekehr" class="login_btn"/>
				</li>
			</form>
			<form action="../quiz/wordquiz4.html" method="POST">
				<li>
					<input type="submit" value="Tiere" class="login_btn"/>
				</li>   
			</form>  
			<form action="../quiz/wordquiz.html" method="POST">
				<li>
					<input type="submit" value="Ebbinghaus" class="login_btn"/>
				</li>   
			</form>  
		</ul>
	</fieldset>

<fieldset>
	<legend>Review&Inserting</legend>
	<ul>

<!-- Review quiz -->
<form action="../quiz/review.html" method="POST">
	<li>
		<input type="submit" name="category" value="Review" class="login_btn"/>
	</li>
</form>

<!-- Insert new words -->
 <form action="../insert/insert.html" method="POST">
	<li>
		<input type="submit" name="alter" value="Adding New Words" class="login_btn"/>
	</li>
</form> 

</ul>
</fieldset>
<br>
<br>
<button type="submit" name="category" value="Log Out" onclick="logout()" class="login_btn">Log Out</button>
<script>
	function logout(){//Log out 
		if(confirm("Are you sure log out?")){
			window.location="../index.html";
		}
	}
</script>
</body>
 
</html>
