
<?php
/* Login 
Written by ZHAO */

header("Content-type:text/html;charset=utf-8");
header("Access-Control-Allow-Origin: *");   

session_start();
            $username = $_POST["username"];
            $_SESSION['username']=$username;

if(isset($_POST["login"]) ) {
    $username = $_POST["username"];   //username
    $password = $_POST["password"]; //password

    require_once('../database/connect_sql.php');

    //Judge if the user is existed
    $sql = "SELECT * FROM user WHERE user_name = '$_POST[username]';";

    $result = mysqli_query($link, $sql);    
    if (!$result) {
        printf("Error: %s\n", mysqli_error($link));
        exit();
    }
    $rows = mysqli_num_rows($result); 

    if ($rows == 0) {     //The user is not existed
        $json_arr = array('success' => -1);
        header('refresh:3;url=../index.html');
			echo "The user is not existed, after 3 seconds go back to mainpage";
    }
    else {
        $sql = "SELECT password FROM user WHERE password = '$_POST[password]' AND user_name= '$_POST[username]'";
        $result = mysqli_query($link, $sql);
        if (!$result) {
            printf("Error: %s\n", mysqli_error($link));
            exit();
        }
        $rows = mysqli_num_rows($result);

        if ($rows == 1) { //The password is correct
            header('refresh:1; user.php');
        }
        else {  
            //Username or Password wrong
			header('refresh:3;url=../index.html');
			echo "Username or Password wrong，after 3 seconds go back to mainpage";
			exit;
        }
    }

}
