-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- 主机： 127.0.0.1
-- 生成日期： 2021-05-12 20:21:03
-- 服务器版本： 10.4.18-MariaDB
-- PHP 版本： 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `words`
--

-- --------------------------------------------------------

--
-- 表的结构 `bank`
--

CREATE TABLE `bank` (
  `word` varchar(30) NOT NULL,
  `user_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `bank`
--

INSERT INTO `bank` (`word`, `user_name`) VALUES
('Fisch', '1'),
('Apfel', '1'),
('Fisch', '123'),
('Fisch', 'loreley'),
('Gans', 'loreley'),
('Schaf', 'loreley'),
('Fuchs', 'loreley'),
('Reh', 'loreley'),
('Fisch', '123456'),
('Apfel', '123456'),
('Brief', '123456'),
('Wange', '123456'),
('Haar', '123456');

-- --------------------------------------------------------

--
-- 表的结构 `memory_period`
--

CREATE TABLE `memory_period` (
  `p_id` int(1) NOT NULL,
  `p_length` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `memory_period`
--

INSERT INTO `memory_period` (`p_id`, `p_length`) VALUES
(1, 300),
(2, 1800),
(3, 43200),
(4, 86400),
(5, 172800),
(6, 345600),
(7, 604800),
(8, 1296000);

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE `user` (
  `user_name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`user_name`, `password`) VALUES
('1', '1'),
('123', '123'),
('loreley', '123456'),
('123456', '123');

-- --------------------------------------------------------

--
-- 表的结构 `user_word`
--

CREATE TABLE `user_word` (
  `user_name` varchar(20) NOT NULL,
  `word` varchar(30) NOT NULL,
  `last_learn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `word_period` int(1) NOT NULL,
  `mistake_mark` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `user_word`
--

INSERT INTO `user_word` (`user_name`, `word`, `last_learn`, `word_period`, `mistake_mark`) VALUES
('1', 'Taxi', '2021-05-12 13:09:31', 5, 0),
('123456', 'Apfel', '2021-05-11 10:13:47', 3, 0),
('123456', 'Auge', '2021-05-11 20:13:59', 2, 3),
('123456', 'Bier', '2021-05-11 10:46:30', 3, 0),
('123456', 'Boot', '2021-05-11 10:49:05', 3, 0),
('123456', 'Brief', '2021-05-11 17:47:10', 2, 2),
('123456', 'Ei', '2021-05-11 11:23:45', 3, 0),
('123456', 'Erdbeere', '2021-05-11 10:43:54', 3, 0),
('123456', 'Flugzeug', '2021-05-11 11:06:04', 2, 0),
('123456', 'Gans', '2021-05-11 20:13:53', 3, 0),
('123456', 'Gurke', '2021-05-11 10:49:46', 3, 0),
('123456', 'Hahn', '2021-05-11 20:13:49', 2, 1),
('123456', 'Katze', '2021-05-11 11:23:42', 3, 0),
('123456', 'Kuchen', '2021-05-11 10:49:28', 3, 0),
('123456', 'Motorrad', '2021-05-11 10:49:30', 3, 0),
('123456', 'Nase', '2021-05-11 10:49:11', 3, 0),
('123456', 'Nudel', '2021-05-11 10:46:25', 3, 0),
('123456', 'Nuss', '2021-05-11 20:13:45', 2, 1),
('123456', 'Reh', '2021-05-11 11:11:26', 4, 0),
('123456', 'Schinken', '2021-05-11 10:50:31', 3, 0),
('123456', 'Schwein', '2021-05-11 11:24:56', 10, 0),
('123456', 'Steak', '2021-05-11 11:11:22', 4, 0),
('123456', 'Taxi', '2021-05-11 10:13:43', 3, 0),
('123456', 'Tee', '2021-05-11 11:23:39', 3, 0),
('123456', 'Verkehr', '2021-05-11 10:13:50', 3, 0),
('123456', 'Wagen', '2021-05-11 10:49:43', 3, 0),
('123456', 'Zahn', '2021-05-11 10:13:53', 3, 0);

-- --------------------------------------------------------

--
-- 表的结构 `vocabulary`
--

CREATE TABLE `vocabulary` (
  `word` varchar(30) NOT NULL,
  `gender` char(10) NOT NULL,
  `category` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `vocabulary`
--

INSERT INTO `vocabulary` (`word`, `gender`, `category`) VALUES
('Brief', 'der', '1'),
('', '', ''),
('Hand', 'der', '2'),
('Fuess', 'der', '2'),
('Haar', 'der', '2'),
('', '', ''),
('Erdbeere', 'die', '1'),
('Apfel', 'der', '1'),
('Fisch', 'der', '4'),
('Bus', 'der', '3'),
('Auto', 'das', '3'),
('Ei', 'das', '1'),
('Nuss', 'die', '1'),
('Fleisch', 'das', '1'),
('Nudel', 'die', '1'),
('Zitrone', 'die', '1'),
('Marzipan', 'das', '1'),
('Gurke', 'die', '1'),
('Tee', 'der', '1'),
('Bier', 'das', '1'),
('Wust', 'die', '1'),
('Honig', 'der', '1'),
('Kuchen', 'der', '1'),
('Schinken', 'der', '1'),
('Steak', 'das', '1'),
('Kraut', 'das', '1'),
('Gesicht', 'das', '2'),
('Stirn', 'die', '2'),
('Wange', 'die', '2'),
('Ohr', 'das', '2'),
('Hals', 'der', '2'),
('Nase', 'die', '2'),
('Auge', 'das', '2'),
('Mund', 'der', '2'),
('Zahn', 'der', '2'),
('Haut', 'die', '2'),
('Magen', 'der', '2'),
('Leber', 'die', '2'),
('Verkehr', 'der', '3'),
('Fahrrad', 'das', '3'),
('Wagen', 'der', '3'),
('Taxi', 'der', '3'),
('Motorrad', 'das', '3'),
('Flugzeug', 'das', '3'),
('Schiff', 'das', '3'),
('Bahn', 'die', '3'),
('Boot', 'das', '3'),
('Katze', 'die', '4'),
('Schwein', 'das', '4'),
('Gans', 'die', '4'),
('Schaf', 'das', '4'),
('Hahn', 'der', '4'),
('Insekt', 'das', '4'),
('Schwan', 'der', '4'),
('Affe', 'der', '4'),
('Fuchs', 'der', '4'),
('Hase', 'der', '4'),
('Loewe', 'der', '4'),
('Reh', 'das', '4'),
('Rind', 'das', '4'),
('Reis', 'das', '1');

--
-- 转储表的索引
--

--
-- 表的索引 `user_word`
--
ALTER TABLE `user_word`
  ADD PRIMARY KEY (`user_name`,`word`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
