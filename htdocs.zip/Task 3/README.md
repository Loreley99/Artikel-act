


<br />
<p align="center">
  <h1 align="center">DER DIE DAS</h1>
  <p align="center">
    <big><b>LEARN GERMAN EASY!</b></big>
    </p>
</p>

<!-- TABLE OF CONTENTS -->
## Table of Contents

* About the Project
* Getting Started
* Contact



<!-- ABOUT THE PROJECT -->
## About our Website


DER DIE DAS is a is a web-based application to help German learners memorise the gender of German nouns. 


## Getting Started

### Install the Application

1. Unzip the TASK3 package into your XAMPP file directory under htdocs.

2. Import the words.sql file from the zip package into MySQL and name the database "words".

3. Then change the username and password of the database in the connect_sql.php file in the database folder in task3 to your own information.

4. Finally, open index.html and you can run the program.


### Sign up and Sign in

If you do not have account Click **Register** to sign up your own account at the first time.


### What if I want to change password?

Click **Alter Password** Button to reset your password. 


#### Learning New Words
1. Click the category you want to learn.
2. Follow the instructions in the quiz screen.
3. When you want to save the current word into bank click **Saving**.
4. Click **Next** and **Back** can help you switch the word.

#### Review words
1. Click **Review** to review session.
2. Click `Delect` if you want to delect current word from your bank.


#### Insert new word into vocabulary
Click **Adding New Words**

### The Pictures used all come from app Duitang


<!-- CONTACT -->
## Contact

ZHAO Raoyuan -  raoyuan.zhao@stud.th-luebeck.de
FENG Tianshi -  tianshi.feng@stud.th-luebeck.de









