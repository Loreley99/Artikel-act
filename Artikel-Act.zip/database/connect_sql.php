<?php
/* <!--connect to the mysqli_connect
 Written by ZHAO -->
 */
error_reporting(0);

header("Content-type:text/html;charset=utf-8");	//define
header("Access-Control-Allow-Origin: *");

session_start();	

$host = 'localhost'; //adress of computer
$database = 'words';   //name of the database
$username = 'root'; //username of database
$password = '123456'; //the password of database

/*
 connect the database
 */
$link = mysqli_connect($host, $username, $password);    
mysqli_select_db($link, "words");
mysqli_query($link,"set names 'utf8'");
if (!$link) {

    die("could not connect to the database.\n" . mysqli_error($link));//error alert
}
?>
