
<html>
<head>
	<title>php backstage programm</title>
	<meta charset="utf-8">
	</head>
<body>
<?php
/* Realize the insert function
Written by ZHAO */

		//receive the data
		function get_str($str){
			$val = ($_POST[$str])?$_POST[$str]:null;
			return $val;
		}

		$word = get_str("word");
		$char = $_POST["gender"];
		$tran = $_POST["cate"];

		if($word == null or $char == null or $tran == null){//if the information is not completed
			echo "Please enter all the information!after 3 seconds go back to insert page";
			header('refresh:3;url=insert.html');
		}else{

		include "../database/connect_sql.php";//connect the database

		 //Check if the word is already existed
		 $sql = "select * from vocabulary where word='$word'";
		 $result = mysqli_query($link, $sql);    
		 if (!$result) {
			 printf("Error: %s\n", mysqli_error($link));
			 exit();
		 }
		 $num = mysqli_num_rows($result);

		 if($num){//if the word has already existed
			 echo "The word is already exisiting!after 3 seconds go back to insert page";
			 header('refresh:3;url=insert.html');
		 }else{
		$sql_insert = "insert into vocabulary (word, gender, category)
                      values('$word', '$char', '$tran')";
				$res_insert = mysqli_query($link, $sql_insert);
				
				if($res_insert) {   //Adding successfully
					echo "successfully added!after 3 seconds go back to insert page";
					header('refresh:3;url=insert.html');
                }
                else { 
					echo "Something went wrong, please try again later,after 3 seconds go back to insert page";
					header('refresh:3;url=insert.html');
				}
			}
		}
?>
</body>
</html>
