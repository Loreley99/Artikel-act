<?php
// <!-- Deal with the action from quiz or review page 
// Written by ZHAO -->
$cate=$_POST["cate"];//get know which category the user choose

switch($cate){
case "1"://lebensmittel
    sortted(1);
    break;
case "2"://koerper
    sortted(2);
    break;
case "3"://vekehrsmittel
    sortted(3);
    break;
case "4"://tire
    sortted(4);
    break;
case "re"://user click review
    sortted("review");
    break;
}

// deal with user's require
function sortted($f){
    if($_POST["flag"]=="two"){//the user click submit
        $word1 = new wordSet($f);
        $word1->judge();
    }else if($_POST["flag"]=="one"){//the user click next
        $word1 = new wordSet($f);
        $word1->next();
    }else if($_POST["flag"]=="three"){//the user click saving
        $word1 = new wordSet($f);
        $word1->addToBank();
}else if($_POST["flag"]=="four"){//the user click back
    $word1 = new wordSet($f);
    $word1->next();
}else if($_POST["flag"]=="five"){//the user click delete
    $word1 = new wordSet($f);
    $word1->del();
}
}


class wordSet{

    public $name;
    public $gender;
    public $category;

    // Construct 
    // give the object the value of word,gender and category
    function __construct($database){
        include "../../database/connect_sql.php";//connect the database
        if($database !="review"){
            $sql = "select * from vocabulary where category = '$database' limit 1,1";//select the selected category items and choose the first record
        }else{
            $sql = "select * from word_bank limit 1，1";//the first record from word bank
        }

        $result = mysqli_query($link, $sql);   
            if (!$result) {
                printf("Error: %s\n", mysqli_error($link));
                exit();
            }
            foreach($result as $information){
                $this->name=$information['word'];
                $this->gender=$information['gender'];
                $this->category=$information['category'];
            }

    }

    function judge(){
        include "../../database/connect_sql.php";
        $oder=$_POST['number'];
        $cate=$_POST["cate"];
        if($cate!="re"){//not the review, use vocabulary table
            $sql = "SELECT * FROM vocabulary WHERE category=$cate limit {$oder},1";
        }else{
            session_start();
        $user = $_SESSION['username'];
            $sql ="SELECT * FROM vocabulary WHERE word=(SELECT word FROM bank WHERE user_name='$user' limit {$oder},1)";
        }
        $result = mysqli_query($link, $sql);   
        if (!$result) {
            printf("Error: %s\n", mysqli_error($link));
            exit();
        }

        foreach($result as $information){
            $this->gender=$information['gender'];
        }

        if($this->gender == $_POST["gender"]){
            if($_POST["gender"]=="der"){
                echo 1;
            }else if($_POST["gender"]=="die"){
                echo 2;//if the answer is right
            }else if($_POST["gender"]=="das"){
                echo 3;
            }else{
            echo "You are wrong, try again!";
        }
    }
}

    function next(){
        include "../../database/connect_sql.php";
        $oder=$_POST['number'];
        if($_POST["cate"]!="re"){//not review
            $cate=$_POST["cate"];
            $sql = "SELECT * FROM vocabulary WHERE category=$cate limit {$oder},1";
        }else{
            session_start();
        $user = $_SESSION['username'];//the current username
            $sql = "SELECT * FROM bank WHERE word=(SELECT word FROM bank WHERE user_name='$user' limit {$oder},1)";
        }
        $result = mysqli_query($link, $sql);   
        if (!$result) {
            print("No word back,please click next");
            exit();
        }

        foreach($result as $information){
            $this->name=$information['word']; 
        }
        if($this->name == ""){
        echo "all finished, see u tomorrow!";
       }else{
            echo $this->name;  
       }
    }

    function addToBank(){//add the current word into word bank
        include "../../database/connect_sql.php";
        $oder=$_POST['number'];
        $cate=$_POST["cate"];
        $sql = "select * from vocabulary where category='$cate' limit {$oder},1";
        $result = mysqli_query($link, $sql);    
        if (!$result) {
            printf("Error: %s\n", mysqli_error($link));
            exit();
        }
        foreach($result as $information){
            $this->name=$information['word'];
            $this->gender=$information['gender'];
            $this->category=$information['category'];
        }

        session_start();
        $user = $_SESSION['username'];//get the curren username

        //Check if the word is already existed
        $sql = "select * from bank where word='$this->name' AND user_name='$user'";
        $result = mysqli_query($link, $sql);    
        if (!$result) {
            printf("Error: %s\n", mysqli_error($link));
            exit();
        }
        $num = mysqli_num_rows($result);

        if($this->name==""){//word already existed
            echo "Cannot add empty word";
        }else if($num){//the word is empty
            echo "The word has already been added";
        }else{
        $sql = "insert into bank (word , user_name) values ('$this->name','$user')";
        $res_insert = mysqli_query($link, $sql);
				if($res_insert) {   //Add successfully
					echo "successfully added!";
                }
                else { 
                    echo "Something went wrong,try again later";
                }
            }
        }

    

    function del(){
        include "../../database/connect_sql.php";
        $oder=$_POST['number'];
        $user = $_SESSION['username'];
        $sql = "SELECT word FROM bank WHERE user_name='$user' limit {$oder},1";
        $result = mysqli_query($link, $sql);    
        if (!$result) {
            printf("Error: %s\n", mysqli_error($link));
            exit();
        }
        foreach($result as $information){
            $this->name=$information['word'];
        }

        if($this->name==""){//the current word is empty
            echo "You cannot delete empty word";
        }else{//if not
        $sql = "DELETE FROM bank WHERE word=(SELECT word FROM bank WHERE user_name='$user' limit {$oder},1)";
        $res_del = mysqli_query($link, $sql);
        if($res_del) {   //Delect successfully
            echo "successfully deleted!";
        }
        else { 
            echo "Something went wrong,try again later";
        }
    }
}
    }
?>