<?php
/*Implementaion the eibbinghaus algorithm
Written by ZHAO*/

include "../../database/connect_sql.php";
    session_start();
    $user = $_SESSION['username'];//get the curren username

    if ($_POST["flag"]=="two"){//judge whether if it is right
        include "../../database/connect_sql.php";
        session_start();
        $word1=$_SESSION['word'];
        $user=$_SESSION['username'];
        $sql="INSERT INTO user_word(user_name,word,last_learn,word_period,mistake_mark) VALUE('$user','$word1',NOW(),1,0) ON DUPLICATE KEY UPDATE user_name= '$user',word='$word1'";

        
        $res_update = mysqli_query($link, $sql);
                    if($res_update) {   //Add successfully
                    //successfully update!;
                    }else{
                        echo "something wrong,try again";
                    }

        $sql="SELECT * FROM vocabulary INNER JOIN user_word ON user_word.word=vocabulary.word WHERE user_name='$user' AND vocabulary.word='$word1'";
        $result = mysqli_query($link, $sql);   
            if (!$result) {
                echo "error";
                exit();
            }
        foreach($result as $information){
            $gender=$information['gender'];
            $mark=$information['mistake_mark'];
            $period=$information['word_period'];
        }
         
       
        if($gender == $_POST["gender"]){
            if($mark>0){
             $mark--;   
            }
            if($period>0&&$period<9){
                $period=$period+1;
            }
            $sql = "REPLACE INTO user_word (user_name,word,last_learn,word_period,mistake_mark) VALUE ('$user','$word1',NOW(),$period,$mark)";
            $res_update = mysqli_query($link, $sql);
                    if($res_update) {   //Add successfully
                    //"successfully update!";
                    }
                    else { 
                        echo "update error";
                    }
            if($_POST["gender"]=="der"){
                echo 1;
            }else if($_POST["gender"]=="die"){
                echo 2;//if the answer is right
            }else if($_POST["gender"]=="das"){
                echo 3;
            }
        }else{//answer wrong
                $mark=$mark+2;
                
                $period=$period-1;
                if($period<1){
                    $period=1;
                }
                
                $sql = "REPLACE INTO user_word (user_name,word,last_learn,word_period,mistake_mark) VALUE ('$user','$word1',NOW(),$period,$mark)";
            $res_update = mysqli_query($link, $sql);
                    if($res_update) {   //Add successfully
                    //"successfully update!";
                    }
                    else { 
                        echo "update error";
                    }
            echo "You are wrong, try again!";
            }   
    }

if($_POST["flag"]=="one"){//next word

    if(word_period($user)!=0){//search for period reached word

         echo word_period($user);

    }else if(word_mark($user)!=0){//search for word that has mistake mark
       
        echo word_mark($user);

    }else if(word_new($user)!=0){//the word not learnt
        
        echo word_new($user);
        
    }else if(word_rand($user!=0)){//random review

        echo word_rand($user);
    }else{
        echo word_search();
    }


    }
    
    
    
    

if($_POST['flag']=="three"){//saving to the bank
    include "../../database/connect_sql.php";
    $word=$_SESSION['word'];
    $user=$_SESSION['username'];
    $sql = "SELECT * from bank where word='$word' AND user_name='$user'";
    $result = mysqli_query($link, $sql);    
    if (!$result) {
        printf("Error: %s\n", mysqli_error($link));
        exit();
    }
    $num = mysqli_num_rows($result);

    if($word==""){//word already existed
        echo "Cannot add empty word";
    }else if($num){//the word is empty
        echo "The word has already been added";
    }else{
    $sql = "insert into bank (word , user_name) values ('$word','$user')";
        $res_insert = mysqli_query($link, $sql);
				if($res_insert) {   //Add successfully
					echo "successfully added!";
                }
                else { 
                    echo "Something went wrong,try again later";
                }

}
}


    function word_period($user_name){//search for the word has reached the period
        include "../../database/connect_sql.php";
    session_start();
    $user = $_SESSION['username'];
    $sql = "SELECT * FROM user_word INNER JOIN memory_period ON user_word.word_period=memory_period.p_id WHERE user_name='$user' AND timestampadd(second,p_length,last_learn)<NOW() ORDER BY last_learn LIMIT 1";
        $result = mysqli_query($link, $sql);   
        if (!$result) {
            return 0;
           
        }
        foreach($result as $information){
            $word=$information['word']; 
        }
        if($word == ""){
        return 0;
       }else{
        session_start();
        $_SESSION['word']=$word;
            return $word;  
       }
    }

    function word_mark($user_name){
        include "../../database/connect_sql.php";
        session_start();
    $user = $_SESSION['username'];
        $sql="SELECT * FROM user_word WHERE user_name='$user' AND mistake_mark>0 ORDER BY mistake_mark DESC LIMIT 1";
        $result = mysqli_query($link, $sql);  
        if (!$result) {
            return 0;
        }
        foreach($result as $information){
            $word=$information['word']; 
        }
        if($word == ""){
        return 0;
       }else{
        session_start();
        $_SESSION['word']=$word;
            return $word;  
       }
    }

    function word_new($user_name){
        include "../../database/connect_sql.php";
        session_start();
        $user = $_SESSION['username'];
        $sql="SELECT * FROM vocabulary WHERE word IS NOT null AND word NOT IN (SELECT word FROM user_word WHERE user_name='$user') ORDER BY rand() LIMIT 0,1";
        $result = mysqli_query($link, $sql);  
        if (!$result) {
            return 0;
        }
        foreach($result as $information){
            $word=$information['word']; 
        }
        if($word == ""){
        return 0;
       }else{
        session_start();
        $_SESSION['word']=$word;
            return $word;  
       }
    }

    function word_rand($user_name){
        include "../../database/connect_sql.php";
        session_start();
        $user = $_SESSION['username'];
        $sql="SELECT * FROM user_word WHERE user_name='$user' ORDER BY rand() LIMIT 1 ";
        $result = mysqli_query($link,$sql);  
        if (!$result) {
            return 0;
        }
        foreach($result as $information){
            $word=$information['word']; 
        }
        if($word == ""){
        return 0;
       }else{
        session_start();
        $_SESSION['word']=$word;
            return $word;  
       }

    }

    function word_search(){
        include "../../database/connect_sql.php";
        session_start();
        $sql="SELECT * FROM vocabulary ORDER BY rand() LIMIT 1 ";
        $result = mysqli_query($link,$sql);  
        if (!$result) {
            return "All finished!";
        }
        foreach($result as $information){
            $word=$information['word']; 
        }
        if($word == ""){
        return 0;
       }else{
        session_start();
        $_SESSION['word']=$word;
            return $word;  
       }

    }



    function get_period($user,$word){
        include "../../database/connect_sql.php";
        $sql="SELECT * FROM user_word WHERE user_name='$user' AND word='$word' LIMIT 0,1";
        $result = mysqli_query($link, $sql);    
    if (!$result) {
        return 0;
    }else {foreach($result as $information){
        $period=$information['word_period']; 
       
    } return $period;
    }
    }

    function get_mistake($user,$word){
        include "../../database/connect_sql.php";
        $sql="SELECT * FROM user_word WHERE user_name='$user' AND word='$word' LIMIT 0,1";
        $result = mysqli_query($link, $sql);    
    if (!$result) {
        printf("Error: %s\n", mysqli_error($link));
        echo 0;
    }else {
        foreach($result as $information){
        $mark=$information['mistake_mark']; 
    }
    return $mark;
    }
    }

    function update_word($user_name,$word,$period,$mistake){
        include "../../database/connect_sql.php";
        $sql = "REPLACE INTO user_word (user_name,word,last_learn,word_period,mistake_mark) VALUE ($user_name,$word,NOW(),$period,$mistake)";
        $res_update = mysqli_query($link, $sql);
				if($res_insert) {   //Add successfully
				//"successfully update!";
                }
                else { 
                    echo "wtf";
                }


    }
?>