-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2021-05-31 22:31:16
-- 服务器版本： 8.0.20
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `words`
--

-- --------------------------------------------------------

--
-- 表的结构 `bank`
--

CREATE TABLE IF NOT EXISTS `bank` (
  `word` varchar(30) NOT NULL,
  `user_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- 转存表中的数据 `bank`
--

INSERT INTO `bank` (`word`, `user_name`) VALUES
('Fisch', '1'),
('Apfel', '1'),
('Fisch', '123'),
('Fisch', 'loreley'),
('Gans', 'loreley'),
('Schaf', 'loreley'),
('Fuchs', 'loreley'),
('Reh', 'loreley'),
('Fisch', '123456'),
('Apfel', '123456'),
('Brief', '123456'),
('Wange', '123456'),
('Haar', '123456');

-- --------------------------------------------------------

--
-- 表的结构 `memory_period`
--

CREATE TABLE IF NOT EXISTS `memory_period` (
  `p_id` int NOT NULL,
  `p_length` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- 转存表中的数据 `memory_period`
--

INSERT INTO `memory_period` (`p_id`, `p_length`) VALUES
(1, 300),
(2, 1800),
(3, 43200),
(4, 86400),
(5, 172800),
(6, 345600),
(7, 604800),
(8, 1296000);

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`user_name`, `password`) VALUES
('1', '1'),
('123', '123'),
('loreley', '123456'),
('123456', '123');

-- --------------------------------------------------------

--
-- 表的结构 `user_word`
--

CREATE TABLE IF NOT EXISTS `user_word` (
  `user_name` varchar(20) NOT NULL,
  `word` varchar(30) NOT NULL,
  `last_learn` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `word_period` int NOT NULL,
  `mistake_mark` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- 转存表中的数据 `user_word`
--

INSERT INTO `user_word` (`user_name`, `word`, `last_learn`, `word_period`, `mistake_mark`) VALUES
('1', 'Taxi', '2021-05-12 13:09:31', 5, 0),
('123456', 'Apfel', '2021-05-11 10:13:47', 3, 0),
('123456', 'Auge', '2021-05-11 20:13:59', 2, 3),
('123456', 'Bier', '2021-05-11 10:46:30', 3, 0),
('123456', 'Boot', '2021-05-11 10:49:05', 3, 0),
('123456', 'Brief', '2021-05-11 17:47:10', 2, 2),
('123456', 'Ei', '2021-05-11 11:23:45', 3, 0),
('123456', 'Erdbeere', '2021-05-11 10:43:54', 3, 0),
('123456', 'Flugzeug', '2021-05-11 11:06:04', 2, 0),
('123456', 'Gans', '2021-05-11 20:13:53', 3, 0),
('123456', 'Gurke', '2021-05-11 10:49:46', 3, 0),
('123456', 'Hahn', '2021-05-11 20:13:49', 2, 1),
('123456', 'Katze', '2021-05-11 11:23:42', 3, 0),
('123456', 'Kuchen', '2021-05-11 10:49:28', 3, 0),
('123456', 'Motorrad', '2021-05-11 10:49:30', 3, 0),
('123456', 'Nase', '2021-05-11 10:49:11', 3, 0),
('123456', 'Nudel', '2021-05-11 10:46:25', 3, 0),
('123456', 'Nuss', '2021-05-11 20:13:45', 2, 1),
('123456', 'Reh', '2021-05-11 11:11:26', 4, 0),
('123456', 'Schinken', '2021-05-11 10:50:31', 3, 0),
('123456', 'Schwein', '2021-05-11 11:24:56', 10, 0),
('123456', 'Steak', '2021-05-11 11:11:22', 4, 0),
('123456', 'Taxi', '2021-05-11 10:13:43', 3, 0),
('123456', 'Tee', '2021-05-11 11:23:39', 3, 0),
('123456', 'Verkehr', '2021-05-11 10:13:50', 3, 0),
('123456', 'Wagen', '2021-05-11 10:49:43', 3, 0),
('123456', 'Zahn', '2021-05-11 10:13:53', 3, 0);

-- --------------------------------------------------------

--
-- 表的结构 `vocabulary`
--

CREATE TABLE IF NOT EXISTS `vocabulary` (
  `word` varchar(30) NOT NULL,
  `gender` char(10) NOT NULL,
  `category` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- 转存表中的数据 `vocabulary`
--

INSERT INTO `vocabulary` (`word`, `gender`, `category`) VALUES
('Affe', 'der', '4'),
('Apfel', 'der', '1'),
('Auge', 'das', '2'),
('Auto', 'das', '3'),
('Bahn', 'die', '3'),
('Bier', 'das', '1'),
('Boot', 'das', '3'),
('Bus', 'der', '3'),
('Ei', 'das', '1'),
('Erdbeere', 'die', '1'),
('Fahrrad', 'das', '3'),
('Fisch', 'der', '4'),
('Fleisch', 'das', '1'),
('Flugzeug', 'das', '3'),
('Fuchs', 'der', '4'),
('Fuess', 'der', '2'),
('Gans', 'die', '4'),
('Gesicht', 'das', '2'),
('Gurke', 'die', '1'),
('Haar', 'der', '2'),
('Hahn', 'der', '4'),
('Hals', 'der', '2'),
('Hand', 'der', '2'),
('Hase', 'der', '4'),
('Haut', 'die', '2'),
('Honig', 'der', '1'),
('Insekt', 'das', '4'),
('Katze', 'die', '4'),
('Kraut', 'das', '1'),
('Kuchen', 'der', '1'),
('Leber', 'die', '2'),
('Loewe', 'der', '4'),
('Magen', 'der', '2'),
('Marzipan', 'das', '1'),
('Motorrad', 'das', '3'),
('Mund', 'der', '2'),
('Nase', 'die', '2'),
('Nudel', 'die', '1'),
('Nuss', 'die', '1'),
('Ohr', 'das', '2'),
('Pudding', 'der', '1'),
('Reh', 'das', '4'),
('Reis', 'das', '1'),
('Rind', 'das', '4'),
('Schaf', 'das', '4'),
('Schiff', 'das', '3'),
('Schinken', 'der', '1'),
('Schwan', 'der', '4'),
('Schwein', 'das', '4'),
('Steak', 'das', '1'),
('Stirn', 'die', '2'),
('Taxi', 'der', '3'),
('Tee', 'der', '1'),
('Verkehr', 'der', '3'),
('Wagen', 'der', '3'),
('Wange', 'die', '2'),
('Wust', 'die', '1'),
('Zahn', 'der', '2'),
('Zitrone', 'die', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `memory_period`
--
ALTER TABLE `memory_period`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `user_word`
--
ALTER TABLE `user_word`
  ADD PRIMARY KEY (`user_name`,`word`);

--
-- Indexes for table `vocabulary`
--
ALTER TABLE `vocabulary`
  ADD PRIMARY KEY (`word`,`gender`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
